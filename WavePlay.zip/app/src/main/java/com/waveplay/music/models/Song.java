package com.waveplay.music.models;
public class Song { public String title,artist,path; }