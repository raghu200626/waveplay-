package com.waveplay.music.models;
public abstract class AppDatabase {}