package com.waveplay.music.models;
public interface FavoriteDao {}