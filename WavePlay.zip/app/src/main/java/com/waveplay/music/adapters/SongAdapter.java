package com.waveplay.music.adapters;
public class SongAdapter {}