package com.waveplay.music.activities;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import com.waveplay.music.R;
public class MainActivity extends AppCompatActivity {
  @Override protected void onCreate(Bundle b){ super.onCreate(b); setContentView(R.layout.activity_main); }
}