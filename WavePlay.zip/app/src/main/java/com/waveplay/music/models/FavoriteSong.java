package com.waveplay.music.models;
public class FavoriteSong {}