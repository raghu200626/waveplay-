package com.waveplay.music.adapters;
public class WallpaperAdapter {}